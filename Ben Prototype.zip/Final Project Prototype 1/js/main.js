/* * * * * * * * * * * * * *
*           MAIN           *
* * * * * * * * * * * * * */

// // init global variables, switches, helper functions
// let myPieChart,
//     myMapVis;

let myMapVis,
    myStackedBar;

//
// function updateAllVisualizations(){
//     myPieChart.wrangleData()
//     myMapVis.wrangleData()
// }

// Load data using promises
let promises = [
    d3.csv("data/combined_updated_dataAll.csv"),
    // d3.csv("data/winners.csv"),
    d3.json("data/countries.geojson")
];

Promise.all(promises)
    .then(function (data) {
        initMainPage(data)
    })
    .catch(function (err) {
        console.log(err)
    });

// initMainPage
function initMainPage(allDataArray) {
    console.log(allDataArray);

    myMapVis = new MapVis('mapDiv', allDataArray[0], allDataArray[1], 'winner');
    // myStackedBar = new StackedBar('stackedBarDiv', allDataArray[0], allDataArray[1], 'winner');
}

function criteriaChange() {
    myMapVis.dataType = document.getElementById('mapCriteriaSelector').value;
    myMapVis.wrangleData()
}
