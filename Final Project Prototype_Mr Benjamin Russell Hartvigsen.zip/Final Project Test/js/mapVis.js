/* * * * * * * * * * * * * *
*          MapVis          *
* * * * * * * * * * * * * */


class MapVis {

    constructor(parentElement, hundredData, geoData, dataType, marathonType) {
        this.parentElement = parentElement;
        this.hundredData = hundredData;
        this.geoData = geoData;
        this.dataType = dataType;
        this.marathonType = marathonType;

        this.minYear = 2014;
        this.maxYear = 2023;
        this.marathon = 'all';

        this.minColor = 'lightblue';
        this.maxColor = 'blue';

        this.initVis()
    }

    initVis() {
        let vis = this;

        vis.margin = {top: 20, right: 50, bottom: 10, left: 50};
        vis.width = document.getElementById(vis.parentElement).getBoundingClientRect().width - vis.margin.left - vis.margin.right;
        vis.height = document.getElementById(vis.parentElement).getBoundingClientRect().height - vis.margin.top - vis.margin.bottom;

        // init drawing area
        vis.svg = d3.select("#" + vis.parentElement).append("svg")
            .attr("width", vis.width)
            .attr("height", vis.height)
            .attr('transform', `translate (${vis.margin.left}, ${vis.margin.top})`);

        let scaleFactor = Math.min(vis.height / 610, vis.width / 965);

        // Create projection
        vis.projection = d3.geoEquirectangular()
            .translate([vis.width / 2, vis.height / 2])
            .scale(scaleFactor * 150);

        // Define geo generator and pass in projection
        vis.path = d3.geoPath()
            .projection(vis.projection);

        vis.countries = vis.svg.selectAll("path")
            .data(vis.geoData.features)
            .enter().append("path")
            .attr("d", vis.path)
            .style('stroke', 'black');

        vis.colorScale = d3.scaleLinear()
            .range([vis.minColor, vis.maxColor]);

        // Handle legend
        vis.legendHeight = 20;
        vis.legendWidth = 200;

        // Create continuous color scale gradient for legend
        const gradient = vis.svg.append("defs")
            .append("linearGradient")
            .attr("id", "color-gradient")
            .attr("x1", "0%")
            .attr("y1", "0%")
            .attr("x2", "100%")
            .attr("y2", "0%");

        gradient.append("stop")
            .attr("offset", "0%")
            .style("stop-color", vis.minColor);

        gradient.append("stop")
            .attr("offset", "100%")
            .style("stop-color", vis.maxColor);

        // Create a svg rectangle to display gradient
        vis.svg.append("rect")
            .attr("width", vis.legendWidth)
            .attr("height", vis.legendHeight)
            .style("fill", "url(#color-gradient)")
            .attr("x", 10);

        // Create a scale for the legend axis
        vis.legendScale = d3.scaleLinear()
            .range([0, vis.legendWidth]);

        // Initialize the legend axis
        vis.legendAxis = d3.axisBottom()
            .scale(vis.legendScale);

        vis.svg.append("g")
            .attr("class", "legend-axis axis")
            .attr("transform", "translate(" + (10) + "," + (vis.legendHeight) + ")");

        // Initialize tooltip
        vis.tooltip = d3.select("body").append('div')
            .attr('class', "tooltip")
            .attr('id', 'mapTooltip')

        vis.wrangleData()
    }


    wrangleData() {
        let vis = this;

        vis.displayData = [];

        // Set the number of data points to be included based on what user has selected
        let cutoff = 1;

        if (vis.dataType === 'winner') {
            cutoff = 1;
        }
        else if (vis.dataType === 'topThree') {
            cutoff = 3;
        }
        else if (vis.dataType === 'topHundred') {
            cutoff = 100;
        }
        else {
            cutoff = vis.hundredData.length;
        }

        let combinedData = [];

        if (vis.marathonType === 'all') {
            // Sort the data in ascending order
            let sortedData = vis.hundredData.sort(function (a, b) {
                return a.Seconds - b.Seconds;
            });

            // Group the data based on marathon, year, and gender
            let groupedData = d3.group(sortedData, d => d.Marathon, d => d.Year, d => d.Gender);

            groupedData.forEach((marathonMap, marathon) => {
                marathonMap.forEach((yearMap, year) => {
                    yearMap.forEach((genderArray, gender) => {
                        combinedData = combinedData.concat(genderArray.slice(0, cutoff));
                    });
                });
            });
        }

        else if (vis.marathonType === 'boston') {

            // Sort the data in ascending order
            let sortedData = vis.hundredData.sort(function (a, b) {
                return a.Seconds - b.Seconds;
            });

            // Group the data by gender
            const groupedData = d3.group(sortedData, d => d.Gender);

            // Combine the top men and women into a single array
            groupedData.forEach(d => {
                combinedData = combinedData.concat(d.slice(0, cutoff));
            })
        }

        // Get value counts for each country in filtered data
        let countByCountry = combinedData.reduce((acc, obj) => {
            let country = obj.Country;

            // If the country is not in the accumulator, add it with a count of 1
            if (!acc[country]) {
                acc[country] = 1;
            } else {
                // If the country is already in the accumulator, increment the count
                acc[country]++;
            }

            return acc;
        }, {});

        vis.displayData = countByCountry;

        vis.updateVis()
    }
//
    updateVis() {
        let vis = this;

        // Update scale domains
        vis.colorScale.domain([0, d3.max(Object.values(vis.displayData))]);
        vis.legendScale.domain([0, d3.max(Object.values(vis.displayData))]);

        // Update the legend axis ticks
        let totalTicks = 5;
        if (d3.max(Object.values(vis.displayData)) < 5) {
            totalTicks = d3.max(Object.values(vis.displayData));
        }

        vis.legendAxis
            .ticks(totalTicks)
            .tickFormat(d3.format(".0s"));

        // Display the axis
        vis.svg.select(".legend-axis")
            .transition()
            .duration(800)
            .call(vis.legendAxis);

        vis.countries
            // Update states color based on number of winners
            .attr("fill", d => {
                // let match = vis.displayData.find(obj => obj === d.properties.ISO_A3);
                let match = vis.displayData[d.properties.ISO_A3]
                if (match) {
                    return vis.colorScale(match);
                }
                // Handle case where there is not data
                else {
                    return "lightgrey";
                }
            })

    }
}